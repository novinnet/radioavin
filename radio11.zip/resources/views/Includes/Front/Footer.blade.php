
    <footer>
        <div class="container">
            <!-- <div class="row justify-content-center">
                <div class="col-6">
                    <div class="footer-menu">
                        <ul>
                            <li><a href="#">Music</a></li>
                            <li><a href="#">Music</a></li>
                            <li><a href="#">Music</a></li>
                            <li><a href="#">Music</a></li>
                            <li><a href="#">Music</a></li>
                            <li><a href="#">Music</a></li>
                        </ul>
                    </div>
                </div>
            </div> -->
            <div class="row mt-2 justify-content-center">
                <div class="col-12 col-md-6 ">
                    <span class="copy-write-text text-center">
                        © 2020 by RadioAvin. All Rights Reserved.
                        
                    </span>
                </div>
            </div>
        </div>
    </footer>