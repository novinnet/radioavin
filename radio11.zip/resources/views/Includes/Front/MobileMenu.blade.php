<div id="mobile-menu"  class="col-12">
    <div class="toggle" >
        <a href="#" class="mobile-menu text-white" > <span style="margin-right: 6px;
        display: inline-block;">menu</span> <i class="fa fa-caret-right"></i></a>
    </div>
    <div class="mobile-menu-content hidden " >

          <div class="" style="width: 50%;
            padding: 25px 0;
            text-align: center;      background: #212121de;">
            <a href="{{route('Mp3s')}}" style="color: #e6e6e6e6;"> 
                <i class="fa fa-home"></i></a>
        </div>
        <div class="" style="width: 50%;
            padding: 25px 0;
            text-align: center;      background: #212121de;">
            <a href="{{route('Mp3s')}}" style="color: #e6e6e6e6;"> <i class="fa fa-headphones"></i>
                MP3s</a>
        </div>
        <div class="" style="color: #e6e6e6e6;width: 50%;
                padding: 25px 0;
                text-align: center;    border-left: 1px solid #303030;    background: #212121de;">
            <a href="{{route('Videos')}}" style="color: #e6e6e6e6;"> <i class="fa fa-video"></i>
                video</a>
        </div>
        {{-- <div class="" style="color: #e6e6e6e6;width: 50%;
                padding: 25px 0;
                text-align: center;  border-left: 1px solid #303030;    background: #212121de;">
            <a href="{{route('Photos')}}" style="color: #e6e6e6e6;"><i class="fa fa-camera"></i>
                photos</a>
        </div> --}}
          <div class="" style="color: #e6e6e6e6;width: 50%;
                padding: 25px 0;
                text-align: center;  border-left: 1px solid #303030;    background: #212121de;">
            <a href="{{route('Playlists')}}" style="color: #e6e6e6e6;"><i class="fa fa-camera"></i>
                PlayList</a>
        </div>
    </div>
</div>