 <div id="alphabetic_browse" class="container mb-5 my-md-5 text-center">
    <a href="#" id="BrowseAll"> All</a>
    <a href="#">#</a>
    <a href="{{route('Filter')}}?q=A">A</a>
    <a href="{{route('Filter')}}?q=B">B</a>
    <a href="{{route('Filter')}}?q=C">C</a>
    <a href="{{route('Filter')}}?q=D">D</a>
    <a href="{{route('Filter')}}?q=E">E</a>
    <a href="{{route('Filter')}}?q=F">F</a>
    <a href="{{route('Filter')}}?q=G">G</a>
    <a href="{{route('Filter')}}?q=H">H</a>
    <a href="{{route('Filter')}}?q=I">I</a>
    <a href="{{route('Filter')}}?q=J">J</a>
    <a href="{{route('Filter')}}?q=K">K</a>
    <a href="{{route('Filter')}}?q=L">L</a>
    <a href="{{route('Filter')}}?q=M">M</a>
    <a href="{{route('Filter')}}?q=N">N</a>
    <a href="{{route('Filter')}}?q=O">O</a>
    <a href="{{route('Filter')}}?q=P">P</a>
    <a href="{{route('Filter')}}?q=Q">Q</a>
    <a href="{{route('Filter')}}?q=R">R</a>
    <a href="{{route('Filter')}}?q=S">S</a>
    <a href="{{route('Filter')}}?q=T">T</a>
    <a href="{{route('Filter')}}?q=U">U</a>
    <a href="{{route('Filter')}}?q=V">V</a>
    <a href="{{route('Filter')}}?q=W">W</a>
    <a href="{{route('Filter')}}?q=X">X</a>
    <a href="{{route('Filter')}}?q=Y">Y</a>
    <a href="{{route('Filter')}}?q=Z">Z</a>
</div> 

