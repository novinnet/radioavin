<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <div class='container' text-align="center">
        <h3 class="panel-title navbar-brand"><?php echo $emailContent['Header']; ?></h3>
        <?php echo $emailContent['Content']; ?>

        <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
                <td align="center">
                    <div>
                        
                    </div>
                </td>
            </tr>
        </table>
        
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\tm\resources\views/emails/sendmail.blade.php ENDPATH**/ ?>