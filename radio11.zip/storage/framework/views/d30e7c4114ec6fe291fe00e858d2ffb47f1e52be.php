 <div id="alphabetic_browse" class="container mb-5 my-md-5 text-center">
    <a href="#" id="BrowseAll"> All</a>
    <a href="#">#</a>
    <a href="<?php echo e(route('Filter')); ?>?q=A">A</a>
    <a href="<?php echo e(route('Filter')); ?>?q=B">B</a>
    <a href="<?php echo e(route('Filter')); ?>?q=C">C</a>
    <a href="<?php echo e(route('Filter')); ?>?q=D">D</a>
    <a href="<?php echo e(route('Filter')); ?>?q=E">E</a>
    <a href="<?php echo e(route('Filter')); ?>?q=F">F</a>
    <a href="<?php echo e(route('Filter')); ?>?q=G">G</a>
    <a href="<?php echo e(route('Filter')); ?>?q=H">H</a>
    <a href="<?php echo e(route('Filter')); ?>?q=I">I</a>
    <a href="<?php echo e(route('Filter')); ?>?q=J">J</a>
    <a href="<?php echo e(route('Filter')); ?>?q=K">K</a>
    <a href="<?php echo e(route('Filter')); ?>?q=L">L</a>
    <a href="<?php echo e(route('Filter')); ?>?q=M">M</a>
    <a href="<?php echo e(route('Filter')); ?>?q=N">N</a>
    <a href="<?php echo e(route('Filter')); ?>?q=O">O</a>
    <a href="<?php echo e(route('Filter')); ?>?q=P">P</a>
    <a href="<?php echo e(route('Filter')); ?>?q=Q">Q</a>
    <a href="<?php echo e(route('Filter')); ?>?q=R">R</a>
    <a href="<?php echo e(route('Filter')); ?>?q=S">S</a>
    <a href="<?php echo e(route('Filter')); ?>?q=T">T</a>
    <a href="<?php echo e(route('Filter')); ?>?q=U">U</a>
    <a href="<?php echo e(route('Filter')); ?>?q=V">V</a>
    <a href="<?php echo e(route('Filter')); ?>?q=W">W</a>
    <a href="<?php echo e(route('Filter')); ?>?q=X">X</a>
    <a href="<?php echo e(route('Filter')); ?>?q=Y">Y</a>
    <a href="<?php echo e(route('Filter')); ?>?q=Z">Z</a>
</div> 

<?php /**PATH C:\xampp\htdocs\radio\resources\views/Includes/Front/Alfabet.blade.php ENDPATH**/ ?>