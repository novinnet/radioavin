<!DOCTYPE HTML>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
</head>

<body>
    <?php echo e($title); ?>

    <hr>
    <?php echo $content; ?>



</body>

</html><?php /**PATH C:\xampp\htdocs\tm\resources\views/emails/send.blade.php ENDPATH**/ ?>