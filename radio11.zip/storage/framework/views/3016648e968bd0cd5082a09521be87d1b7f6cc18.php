  <section class="slider d-none d-md-block">
        <div class="swiper-container header-slider">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="slider-box">
                        <div class="shadow-bottom-slider"></div>
                        <img class="slider-back-img" src="<?php echo e(asset('frontend/assets/images/slider/p1.jpg')); ?>" alt="">
                        <div class="movie-details-box-slider">
                            <a href="#">
                                <img src="<?php echo e(asset('frontend/assets/images/slider/slider-detail-1.png')); ?>" alt="">
                            </a>
                            <h4>
                                اسم فیلم
                            </h4>
                            <h5>
                                توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات
                                توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات
                                توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات
                                توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات ...
                            </h5>
                            <a href="#" class="page-movie-play btn--ripple">
                                <i class="fa fa-play"></i>
                                پخش فیلم
                            </a>
                            <a href="#" class="more-detail-movie btn--ripple">
                                <i class="fa fa-exclamation"></i>
                                جزئیات بیشتر
                            </a>
                            <h6>
                                ستارگان:
                                <a href="#">
                                    ستاره 1-
                                </a>
                                <a href="#">
                                    ستاره 2-
                                </a>
                                <a href="#">
                                    ستاره 3-
                                </a>
                                <a href="#">
                                    ستاره 4-
                                </a>
                                <a href="#">
                                    ستاره 5-
                                </a>
                                <a href="#">
                                    ستاره 6-
                                </a>
                                <a href="#">
                                    ستاره 7
                                </a>
                            </h6>
                            <h6>
                                کارگران:
                                <a href="#">
                                    کارگردان
                                </a>
                            </h6>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="slider-box">
                        <div class="shadow-bottom-slider"></div>
                        <img class="slider-back-img" src="<?php echo e(asset('frontend/assets/images/slider/p2.jpg')); ?>" alt="">
                        <div class="movie-details-box-slider">
                            <a href="#">
                                <img src="<?php echo e(asset('frontend/assets/images/slider/slider-detail-1.png')); ?>" alt="">
                            </a>
                            <h4>
                                اسم فیلم
                            </h4>
                            <h5>
                                توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات
                                توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات
                                توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات
                                توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات ...
                            </h5>
                            <a href="#" class="page-movie-play btn--ripple">
                                <i class="fa fa-play"></i>
                                پخش فیلم
                            </a>
                            <a href="#" class="more-detail-movie btn--ripple">
                                <i class="fa fa-exclamation"></i>
                                جزئیات بیشتر
                            </a>
                            <h6>
                                ستارگان:
                                <a href="#">
                                    ستاره 1-
                                </a>
                                <a href="#">
                                    ستاره 2-
                                </a>
                                <a href="#">
                                    ستاره 3-
                                </a>
                                <a href="#">
                                    ستاره 4-
                                </a>
                                <a href="#">
                                    ستاره 5-
                                </a>
                                <a href="#">
                                    ستاره 6-
                                </a>
                                <a href="#">
                                    ستاره 7
                                </a>
                            </h6>
                            <h6>
                                کارگران:
                                <a href="#">
                                    کارگردان
                                </a>
                            </h6>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="slider-box">
                        <div class="shadow-bottom-slider"></div>
                        <img class="slider-back-img" src="<?php echo e(asset('frontend/assets/images/slider/p3.jpg')); ?>" alt="">
                        <div class="movie-details-box-slider">
                            <a href="#">
                                <img src="<?php echo e(asset('frontend/assets/images/slider/slider-detail-1.png')); ?>" alt="">
                            </a>
                            <h4>
                                اسم فیلم
                            </h4>
                            <h5>
                                توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات
                                توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات
                                توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات
                                توضیحات توضیحات توضیحات توضیحات توضیحات توضیحات ...
                            </h5>
                            <a href="#" class="page-movie-play btn--ripple">
                                <i class="fa fa-play"></i>
                                پخش فیلم
                            </a>
                            <a href="#" class="more-detail-movie btn--ripple">
                                <i class="fa fa-exclamation"></i>
                                جزئیات بیشتر
                            </a>
                            <h6>
                                ستارگان:
                                <a href="#">
                                    ستاره 1-
                                </a>
                                <a href="#">
                                    ستاره 2-
                                </a>
                                <a href="#">
                                    ستاره 3-
                                </a>
                                <a href="#">
                                    ستاره 4-
                                </a>
                                <a href="#">
                                    ستاره 5-
                                </a>
                                <a href="#">
                                    ستاره 6-
                                </a>
                                <a href="#">
                                    ستاره 7
                                </a>
                            </h6>
                            <h6>
                                کارگران:
                                <a href="#">
                                    کارگردان
                                </a>
                            </h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="next-header-slide">
                <i class="fa fa-angle-right"></i>
            </div>
            <div class="prev-header-slide">
                <i class="fa fa-angle-left"></i>
            </div>
        </div>
    </section><?php /**PATH C:\xampp\htdocs\radio\resources\views/Includes/Front/DesktopSlider.blade.php ENDPATH**/ ?>